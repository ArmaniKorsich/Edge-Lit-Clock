/*
	eLite.h - Library for led Control of edge Lit informational displays.
	Created by Armani D. Korsich, March 2, 2018.
*/
#ifndef eLite_h
#define eLite_h

#include "Arduino.h"
#include <stdio.h>
#include <FastLED.h>

class eLite
{
  public:
    eLite(uint8_t ledStripPin, int ledStripLength, bool printFuncName);
    uint8_t defineChain(uint8_t numDisplays,...);
    void defineLedPerPanel(uint8_t led,...);
    void setStandardOrder(uint8_t displayToConfigure);
    void redefinePanelOrder(uint8_t displayToConfigure, uint8_t quantityPanels,...);
    void drawPanel(uint8_t r, uint8_t g, uint8_t b, uint8_t displayCount, int panelToDraw);
    void drawChain(uint8_t r, uint8_t g, uint8_t b, uint8_t lengthOfChain,...);
    void cycleDisplays(int delayTime, int acceleration, bool direc, uint8_t r, uint8_t g, uint8_t b, uint8_t qtyToCycle,...);
    void clearDisplay(uint8_t displayToClear);
    void clearChain();
    uint8_t setChainBrightness(uint8_t brightness);
	void randomizeDisplays(int delayTime, int acceleration, int iterations, uint8_t r, uint8_t g, uint8_t b, uint8_t qtyToRandomize, ...);
  private:
    CRGB *leds;
	CLEDController *controller;
	//FastLED.addLeds<WS2812B, 6>(leds, 26);
    uint8_t chainLength;
	bool printNames = 0;
	//const int stripPin;
	uint8_t brightnessLevel = 255;
	float brightnessMult;
	const int stripLength;
    const int maxDisplays;
	const int maxLedsPer;
	const int maxPanels;
    boolean chainDefined = false;
	#define maxPanels 10
	#define maxDisplays 5
    int panelCount[maxPanels];
    int ledsPer[maxDisplays];
    int value[maxPanels];
    int panelOrder[maxDisplays][maxPanels];
    #define forward 1 //forward and reverse for the cycleDisplay cycling direction.
    #define reversed 0
};
#endif