/*
	eLite.h - Library for led Control of edge Lit informational displays.
	Created by Armani D. Korsich, March 2, 2018.
*/
#include "Arduino.h"
#include "eLite.h"
#include <stdio.h>
#include <FastLED.h>

eLite::eLite(uint8_t ledStripPin, int ledStripLength, bool printFuncName) {
  #define ledType WS2812B
  #define colorType GRB
  printNames = printFuncName;
  leds = new CRGB[ledStripLength];
  if (ledStripPin == 0) { //Geez FastLED just will not compile otherwise.
	controller = &FastLED.addLeds<ledType, 0, colorType>(leds, ledStripLength);
  } if (ledStripPin == 1) {
	controller = &FastLED.addLeds<ledType, 1, colorType>(leds, ledStripLength);
  } if (ledStripPin == 2) {
	controller = &FastLED.addLeds<ledType, 2, colorType>(leds, ledStripLength);
  } if (ledStripPin == 3) {
	controller = &FastLED.addLeds<ledType, 3, colorType>(leds, ledStripLength);
  } if (ledStripPin == 4) {
	controller = &FastLED.addLeds<ledType, 4, colorType>(leds, ledStripLength);
  } if (ledStripPin == 5) {
	controller = &FastLED.addLeds<ledType, 5, colorType>(leds, ledStripLength);
  } if (ledStripPin == 6) {
	controller = &FastLED.addLeds<ledType, 6, colorType>(leds, ledStripLength);
  } if (ledStripPin == 7) {
	controller = &FastLED.addLeds<ledType, 7, colorType>(leds, ledStripLength);
  } if (ledStripPin == 8) {
	controller = &FastLED.addLeds<ledType, 8, colorType>(leds, ledStripLength);
  } if (ledStripPin == 9) {
	controller = &FastLED.addLeds<ledType, 9, colorType>(leds, ledStripLength);
  } if (ledStripPin == 10) {
	controller = &FastLED.addLeds<ledType, 10, colorType>(leds, ledStripLength);
  } if (ledStripPin == 11) {
	controller = &FastLED.addLeds<ledType, 11, colorType>(leds, ledStripLength);
  } if (ledStripPin == 12) {
	controller = &FastLED.addLeds<ledType, 12, colorType>(leds, ledStripLength);
  } if (ledStripPin == 13) {
	controller = &FastLED.addLeds<ledType, 13, colorType>(leds, ledStripLength);
  }
  const int stripLength = ledStripLength;
  /*maxDisplays = 5;
  maxLedsPer = 2;
  maxPanels = 10;
  int panelCount[maxDisplays];
  int ledsPer[maxLedsPer];
  int value[maxPanels];
  int panelOrder[maxDisplays][];*/
}

uint8_t eLite::defineChain(uint8_t numDisplays,...) {
  if(printNames) {Serial.println("eLite.defineChain"); }
  chainLength = numDisplays;
  va_list chainList; va_start (chainList, numDisplays);
  for (uint8_t i = 0; i < chainLength; i++) {
    panelCount[i] = (va_arg(chainList, int));
    for (uint8_t pane=0; pane <= panelCount[i]; pane++) {
      panelOrder[i][pane] = pane;
    } 
  } va_end(chainList);
  chainDefined = true;
  return chainLength;
}

void eLite::defineLedPerPanel(uint8_t led,...) {
  if(printNames) {Serial.println("eLite.defineLedPerPanel"); }
  va_list ledList;
  va_start(ledList, led);
  for (uint8_t whichDisplay = 0; whichDisplay < chainLength; whichDisplay++) {
    ledsPer[whichDisplay] = va_arg(ledList, int);
  } va_end(ledList);
}	

void eLite::setStandardOrder(uint8_t displayToConfigure) {
  if(printNames) {Serial.println("eLite.setStandardOrder"); }
  for (uint8_t pane = 0; pane < panelCount[displayToConfigure]; pane++) {
    panelOrder[displayToConfigure][pane] = pane;
    
  }  
}

void eLite::redefinePanelOrder(uint8_t displayToConfigure, uint8_t quantityPanels,...) {
  if(printNames) {Serial.println("eLite.redefinePanelOrder"); }
  displayToConfigure -= 1;
  uint8_t buf;
  va_list panelOrderList;
  va_start(panelOrderList, quantityPanels);
  for (uint8_t panelNumber = 0; panelNumber <= panelCount[displayToConfigure]; panelNumber++) {
    
    buf = va_arg(panelOrderList, int);
    //buf -= 1;
    
    if (buf > panelCount[displayToConfigure] or buf < 0) {
      setStandardOrder(displayToConfigure);
      return;
    }
    panelOrder[displayToConfigure][buf] = panelNumber;
    //Serial.println(panelOrder[displayToConfigure][5]);
  } va_end(panelOrderList);  
}

void eLite::drawPanel(uint8_t r, uint8_t g, uint8_t b, uint8_t displayCount, int panelToDraw) {
  if(printNames) {Serial.println("eLite.drawPanel"); }
  //displayCount -= 1;
  if (panelToDraw == -1) {
    clearDisplay(displayCount);
    return;
  }
  int displayCountStartingLed = 0;
  for (uint8_t i = 0; i < displayCount; i++) {
    int previousCount = panelCount[i]+1;
    int previousLeds = ledsPer[i];
    displayCountStartingLed += (previousCount * previousLeds);
  } 
  int startLedBuffer = displayCountStartingLed;
  displayCountStartingLed += panelOrder[displayCount][panelToDraw]; //Sets the led to draw to the value of the led of the panel to draw, rather than the absolute first led in the display.
  uint8_t tempVal = ledsPer[displayCount];
  for (uint8_t j = 0; j < tempVal; j++) {
    displayCountStartingLed += ((panelCount[displayCount]+1)*j);
    if (panelToDraw >= 0) {
		brightnessMult = brightnessLevel;
		brightnessMult /= 255;
		uint8_t tempR = r*brightnessMult;
		uint8_t tempG = g*brightnessMult;
		uint8_t tempB = b*brightnessMult;
		
      leds[displayCountStartingLed] = CRGB(tempR, tempG, tempB);/* FastLED.show();*/
	  //controller->showLeds();
    }
    //Serial.println(j);
  }
  FastLED.show(); controller->showLeds();
}

void eLite::drawChain(uint8_t r, uint8_t g, uint8_t b, uint8_t lengthOfChain,...) {
  if(printNames) {Serial.println("eLite.drawChain"); }
  va_list dataList;
  va_start(dataList, lengthOfChain);
  for (uint8_t i = 0; i < chainLength; i++) {
    value[i] = va_arg(dataList, int);
    if (value[i] > panelCount[i] or value[i] < 0) {
      return;
    }
  }
  for (uint8_t i = 0; i<chainLength; i++) {
    drawPanel(r, g, b, i, value[i]);
  }
}  

void eLite::cycleDisplays(int delayTime, int acceleration, bool direc, uint8_t r, uint8_t g, uint8_t b, uint8_t qtyToCycle,...) {
  if(printNames) {Serial.println("eLite.cycleDisplays"); }
  if (direc != forward and direc != reversed) {
    Serial.print("ERROR: Please enter either \reversed\ or \forward\. \""); Serial.print(direc); Serial.println("\" is not an applicable entry.");
    return;
  }
  uint8_t y[qtyToCycle];
  va_list cycleList;
  va_start (cycleList, qtyToCycle);
  for (uint8_t i = 0; i < qtyToCycle; i++) {
    y[i] = va_arg(cycleList, int);
  }
  va_end(cycleList);
  uint8_t largest = 0;
  if (qtyToCycle > 1) {
    for (uint8_t j = 0; j < qtyToCycle; j++) {
      if (panelCount[y[j]] > panelCount[y[largest]]) {
        largest = j;
      }
    }
  }
  if (direc == forward) {
    for (uint8_t panelNumber = 0; panelNumber <= panelCount[y[largest]]; panelNumber++) {
      for (uint8_t displayNumber = 0; displayNumber < qtyToCycle; displayNumber++) {
        if (panelNumber <= panelCount[y[displayNumber]]) {
          clearDisplay(y[displayNumber]);
          drawPanel(r, g, b, y[displayNumber], panelNumber);
        } else { clearDisplay(y[displayNumber]); }
      }
      if (panelNumber != 0) { //Prevents the delayTime from acccelerating on the first cycle iteration
        if (acceleration < 0) { //accel is negative
          if (delayTime >= abs(acceleration)){ //ensures delayTime - acceleration >= 0
            delayTime += (acceleration);
          }
        } else if (acceleration >= 0) { //acel is zero or positive
            delayTime += (acceleration);
          }
      }
      //if (panelNumber != panelCount[y[largest]]){
      delay(delayTime);
      //}
    }
  } else if (direc == reversed) {
    for (uint8_t panelNumber = panelCount[y[largest]]; panelNumber >= 0 ; panelNumber--) {
      for (uint8_t displayNumber = 0; displayNumber < qtyToCycle; displayNumber++) {
        if (panelNumber <= panelCount[y[displayNumber]]) {
          clearDisplay(y[displayNumber]);
          drawPanel(r, g, b, y[displayNumber], panelNumber);
        } else { clearDisplay(y[displayNumber]); }
      }
      if (panelNumber != panelCount[y[largest]]) { //Prevents the delayTime from acccelerating on the first cycle iteration
        if (acceleration < 0) { //accel is negative
          if (delayTime >= abs(acceleration)){ //ensures delayTime - acceleration >= 0
            delayTime += (acceleration);
          }
        } else if (acceleration >= 0) { //acel is zero or positive
            delayTime += (acceleration);
          }
      }
      //if (panelNumber != 0) { //Doesn't delay after lighting the final panel in the cycle.
      delay(delayTime);
      //}
    }  }  }
	
void eLite::randomizeDisplays(int delayTime, int acceleration, int iterations, uint8_t r, uint8_t g, uint8_t b, uint8_t qtyToRandomize, ...) {
  int y[qtyToRandomize];
  va_list cycleList;
  va_start (cycleList, qtyToRandomize);
  for (uint8_t i = 0; i < qtyToRandomize; i++) {
    y[i] = va_arg(cycleList, int);
  }
  va_end(cycleList);
  for (uint8_t iter = 0; iter <= iterations; iter++) {
    for (uint8_t displayNumber = 0; displayNumber < qtyToRandomize; displayNumber++) {
      clearDisplay(y[displayNumber]);
      drawPanel(r, g, b, y[displayNumber], random(0, panelCount[y[displayNumber]]+1));
    }
    if (iter != 0) { //Prevents the delayTime from acccelerating on the first cycle iteration
      if (acceleration < 0) { //accel is negative
        if (delayTime >= abs(acceleration)){ //ensures delayTime - acceleration >= 0
          delayTime += (acceleration);
        }
      } else if (acceleration >= 0) { //acel is zero or positive
          delayTime += (acceleration);
        }
    }
    //if (iter != iterations){
    delay(delayTime);
      //}
    }
  
}

void eLite::clearDisplay(uint8_t displayToClear) {
  if(printNames) {Serial.println("eLite.clearDisplay"); }
  int i = 0;
  int startingLedToClear = 0;
  int endingLedToClear = 0;
  while (i != displayToClear) {
    startingLedToClear += ((panelCount[i]+1)*ledsPer[i]);//lixie[i].panelCount*lixie[i].ledPerPanel);
    i++;
  }
  endingLedToClear = startingLedToClear + ((panelCount[i]+1) * ledsPer[i]) - 1;
  for (int j = startingLedToClear; j <= endingLedToClear; j++) {
    leds[j] = CRGB::Black; //FastLED.show();
  } FastLED.show(); controller->showLeds();
}	

void eLite::clearChain() {
  if(printNames) {Serial.println("eLite.clearChain"); }
  for (int i = 0; i < chainLength; i++) { //clears the entire chain to remove overlap.
    clearDisplay(i);
  }
}

uint8_t eLite::setChainBrightness(uint8_t brightness) {
  if(printNames) {Serial.println("eLite.setChainBrightness"); }
  brightnessLevel = brightness;
  return brightnessLevel;
}
  









